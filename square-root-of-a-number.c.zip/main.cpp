#include<stdio.h>
#include<math.h>
int main()
{
    int x,p;
    printf("enter any number");
    scanf("%d",&x);
p=sqrt(x);
    printf("square of a given number =%d",p);
    return 0;
}