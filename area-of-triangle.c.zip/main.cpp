#include<stdio.h>
int main()
{
    int base,height,area;
    printf("enter base&height values");
    scanf("%d%d",&base,&height);
    area=0.5*base*height;
    printf("area=%d",area);
    return 0;
}