#include<stdio.h>
int main()
{
    float p,t,r,ci;
    printf("enter p,t,r values");
    scanf("%f%f%f",&p,&r,&r);
    ci=p*(pow(1+r/100t)-1);
    printf("ci=%f",ci);
    return 0;
}