#include<stdio.h>
int main()
{
    int a=14,b=23,c;
    c=a+b;
 printf("sum=%d",c);
 return 0;
}