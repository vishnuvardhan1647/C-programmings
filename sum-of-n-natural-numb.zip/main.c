#include <stdio.h>

int main()
{
    int n,i, sum = 0;

    printf("Enter a number");
    scanf("%d", &n);

    for ( i = 1; i <= n; i++)
    {
        sum =(sum+i);
    }

    printf("Sum of n naturl numbers=%d\n", sum);

    return 0;
}