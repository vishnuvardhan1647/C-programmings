#include<stdio.h>
int main()
{
    int bs,da,hra,gs;
printf("enter basic salary");
scanf("%d",&bs);
if(bs<=10000)
{
    da=bs*10/100;
    hra=bs*15/200;
}
else
{
    da=bs*5/100;
    hra=bs*10/100;
}
gs=bs+da+hra+gs;
printf("gross salary=%d",gs);
return 0;
}