#include<stdio.h>
int main()
{
  int s1,s2, s3,total,per;
  printf("enter s1,s2,s3 values");
  scanf("%d%d%d",&s1,&s2,&s3);
  total=s1+s2+s3;
  per=total/3;
  if(s1>=40 && s2>=40 &&s3>40)
  {
      if(per>=90)
  printf("A grade");
  if(per>=75)
  printf("B grade");
  if(per>=60)
  printf("C grade");
  else
  printf("failed");
  }
  return 0;
}