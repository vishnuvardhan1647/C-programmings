#include<stdio.h>
int main()
{
    float f,c;
    printf("enter the value of f");
    scanf("%f",&f);
    c=f-32/1.8;
    printf("c=%F",c);
    return 0;
}