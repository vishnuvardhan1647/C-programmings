#include<stdio.h>
int main()
{
    int a,b;
    printf("enter a and b values");
    scanf("%d%d",&a,&b);
    if(a>b)
    printf("a is big");
    else
    printf("b is big");
    return 0;
}