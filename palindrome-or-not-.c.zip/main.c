#include <stdio.h>
int main()
{
    int num, reversed = 0, remainder, temp;

    printf("Enter a number ");
    scanf("%d", &num);

    temp = num;  
    while (num != 0) 
    {
        remainder = num % 10;           
        reversed = reversed * 10 + remainder; 
        num = num / 10;                 
    }

    if (temp == reversed)
        printf("it is a palindrome");
    else
        printf("it is not a palindrome");

    return 0;
}